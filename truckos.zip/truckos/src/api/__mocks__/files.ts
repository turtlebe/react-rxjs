const getUploadLink = () => null;
const startSingleFileUpload = () => null;
const getDownloadLink = () => null;

export { getUploadLink, startSingleFileUpload, getDownloadLink };
