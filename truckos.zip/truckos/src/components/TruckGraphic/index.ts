export * from './TruckGraphic';
