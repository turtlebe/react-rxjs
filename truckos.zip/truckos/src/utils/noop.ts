/* eslint-disable @typescript-eslint/no-unused-vars */
export const noop = (...args: any[]) => {};
