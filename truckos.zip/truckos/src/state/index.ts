export const PENDING: unique symbol = Symbol('Pending');
export const NEW_ID = '<NEW>';
