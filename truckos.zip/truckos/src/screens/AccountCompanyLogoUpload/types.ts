export interface UploadLogoFormValues {
  logoFilename: string;
  logoUploadId: string;
}
