export interface BankAccountFormValues {
  authorization: boolean;
  bic: string;
  iban: string;
}
