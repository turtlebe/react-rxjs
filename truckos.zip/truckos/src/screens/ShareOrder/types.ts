export interface ShareOrderFormValues {
  email: string | null;
}
