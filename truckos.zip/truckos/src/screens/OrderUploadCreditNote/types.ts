export interface UploadCreditNoteFormValues {
  creditNoteDate: Date | null;
  creditNoteFilename: string;
  creditNoteUploadId: string;
}
