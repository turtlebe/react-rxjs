export interface CreateInvoiceFormValues {
  invoiceNumber: string;
}
