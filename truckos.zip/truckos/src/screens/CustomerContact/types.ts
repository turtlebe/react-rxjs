export interface CustomerContactFormValues {
  contactId: string;
  contactName: string;
  email: string;
  phoneNumber: string;
}
