export interface UploadOrderFormValues {
  orderFilename: string;
  orderUploadId: string;
}
