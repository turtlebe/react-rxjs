export interface RecordPaymentFormValues {
  paymentReceivedOn: Date;
}
