export interface UploadPodFormValues {
  proofOfDeliveryFilename: string;
  proofOfDeliveryUploadId: string;
}
