export * from './KycLightPage';
