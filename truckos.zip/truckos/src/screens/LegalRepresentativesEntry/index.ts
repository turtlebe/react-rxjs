export * from './LegalRepresentativesEntry';
