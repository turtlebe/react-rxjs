export const legalFormCodes = {
  Einzelunternehmen: 'DE0001',
  GbR: 'DE0002',
};
