export const languages = {
  en_US: 'English',
  de_DE: 'German',
};
