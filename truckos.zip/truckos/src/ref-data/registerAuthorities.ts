export const registerAuthorityCodes = {
  Gewerbeamt: 'RADE0001',
};
